import React from 'react';
import ReactDOM from 'react-dom/client';
import Cardssection from './Cardssection';
import Header from './Header';
import Loginbox from './Loginbox';
import PlatinumElite from './image/Platinum Elite.PNG';
import SOLITAIRE from './image/SOLITAIRE.PNG';
import NoonVip from './image/Noon VIP.PNG';
import CashBack from './image/Cash Back.PNG';
import './Cardssection.css'
import Openaccount from './Openaccount'

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
<>
    <Header/>
    
    <section id="webmiddlecontent"> 
     <Loginbox/>
     <section>
      <h1 className="chosecard"> Apply For Your Prefered Card </h1>
          
              
              <div id="Cards">
                  <Cardssection imageName={SOLITAIRE} cardtitle="Solitaire" cardlinks=""/>
                  <Cardssection imageName={PlatinumElite} cardtitle="Platinum Elite" cardlinks=""/>
                  <Cardssection imageName={NoonVip} cardtitle="Noon Vip" cardlinks=""/>
                  <Cardssection imageName={CashBack} cardtitle="Cash Back" cardlinks="" />
              </div>
     </section>
    </section>
    <section>
      <hr className="line"></hr>
        <section id="Body23">
          <Openaccount id="openAccount" Openheading="Open a checking open account" OpenBody="Consider the benefits of opening a Mashreq Banking Account." OpenaccountLink="" 
          Openaccountimg="<img id='openacountimage123' src='https://www.mashreqbank.com/-/jssmedia/Images/UAE/Personal/Products/cards/cashback.ashx?h=227&iar=0&w=355&hash=FEBB1B27698825B37D3268516B768EFF' alt='openaccountimg' className='openaccountimg'>"/>
          <Openaccount id="workTogather" Openheading="Working togather to create jobs for our communites" OpenBody="we are partening with schools and local empolyess to build skills increase hiring, and fuel economic opportunities." OpenaccountLink=""/>
        </section>
    </section>
</>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals

