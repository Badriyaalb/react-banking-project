
function Openaccount(props){

    return(
       <div>
            
    <div>
        <h1 className="heading123" src= {props.Openheading} > </h1>
        <p className= "aboutp2Body" src= {props.OpenBody}> </p> <br/>
        <a className="linkOpenAccount" src={props.OpenaccountLink} href="/Pages/signup.html">Open account</a> &RightArrowBar; <br/>
       {props.Openaccountimg}
        
    </div>
    <div id="workTogather">
        <div id="block">
      <h1 className="heading123"> Working togather to create jobs for our communites</h1>
        <p className= "aboutp2Body">
        we are partening with schools and local empolyess to build skills increase hiring, and fuel economic opportunities.
         </p>
        <a className="linkOpenAccount" href="www.google.com"> Learn more </a> &RightArrowBar;
        </div>
    </div>  
            </div>
        
    )
}