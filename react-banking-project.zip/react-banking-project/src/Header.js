import './Header.css';

function Header(){
return(<div>
    <img src="https://www.mashreqbank.com/kuwait/en/images/logo_tcm75-217770.png" alt=" Mashreq Bank logo" id="BankLogo"/>
            <nav id="menu">
               
                <a href="https://www.mashreqbank.com/en/uae/gold/"  id = "Gold">GOLD </a>
                <a href="https://www.mashreqbank.com/en/uae/private/" id = "Private" >PRIVATE </a>
                <a href="https://www.mashreqbank.com/en/uae/business/" id = "Buisness" >BUISNESS </a>
                <a href="https://www.mashreqbank.com/uae/en/corporate/home" id = "Corporate">CORPORATE </a>
                <a href="https://www.mashreqbank.com/uae/en/corporate/industry-focus/non-banking-financial-institution" id = "Financial" >FINANCIAL INSTITUTION </a>
                <a href="https://www.mashreqalislami.com/en/uae/personal/" id = "Alislami">AL ISLAMI </a>
                
            </nav>
    </div>);
}
export default Header;